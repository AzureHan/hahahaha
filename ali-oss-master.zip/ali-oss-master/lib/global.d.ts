declare let process : {
  browser: string;
  version: string;
  platform: string;
  arch: string;
};
