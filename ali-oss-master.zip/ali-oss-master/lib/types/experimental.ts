export type THeaderEncoding = 'utf-8' | 'latin1';
