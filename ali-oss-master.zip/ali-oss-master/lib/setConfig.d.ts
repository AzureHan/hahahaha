declare let client: any;
export declare const setConfig: (options: any, ctx: any) => void;
export { client };
