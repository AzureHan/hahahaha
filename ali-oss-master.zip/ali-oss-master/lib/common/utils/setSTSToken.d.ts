export declare function setSTSToken(this: any): Promise<void>;
