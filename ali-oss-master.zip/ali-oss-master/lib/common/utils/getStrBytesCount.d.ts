export declare function getStrBytesCount(str: any): number;
