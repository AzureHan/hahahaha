export declare const checkBucketTag: (tag: object) => void;
