export declare function formatInventoryConfig(inventoryConfig: any, toArray?: boolean): any;
