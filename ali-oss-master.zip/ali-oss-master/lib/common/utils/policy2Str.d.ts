export declare function policy2Str(policy: string | object): any;
