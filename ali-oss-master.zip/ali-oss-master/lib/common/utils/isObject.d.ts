export declare const isObject: (obj: any) => boolean;
