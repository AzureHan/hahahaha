export declare function isBuffer(obj: any): boolean;
