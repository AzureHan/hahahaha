export declare function checkObjectTag(tag: any): void;
