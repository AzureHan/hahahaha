export declare const getUserAgent: () => any;
