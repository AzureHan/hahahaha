/// <reference types="node" />
import urlutil from 'url';
export declare function setRegion(region: string, internal?: boolean, secure?: boolean): urlutil.UrlWithStringQuery;
