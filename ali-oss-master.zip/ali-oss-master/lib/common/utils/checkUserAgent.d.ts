export declare const checkUserAgent: (ua: any) => any;
