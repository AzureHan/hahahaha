export declare function retry(this: any, func: Function, retryMax: number, config?: any): (...arg: any[]) => Promise<unknown>;
