export declare const checkBucketName: (name: string, createBucket?: boolean) => void;
