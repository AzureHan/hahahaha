export declare function formatTag(obj: any): {};
