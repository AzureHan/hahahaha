export declare const deepCopy: (obj: any) => any;
