export declare function obj2xml(obj: any, options?: any): string;
