export declare const isFile: (obj: any) => boolean;
