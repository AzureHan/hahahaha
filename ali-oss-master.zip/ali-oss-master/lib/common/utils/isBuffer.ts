export function isBuffer(obj: any) {
  return Buffer.isBuffer(obj);
}
