export declare const isArray: (obj: any) => boolean;
