export declare function isBlob(blob: any): boolean;
