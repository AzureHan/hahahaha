export declare function checkValid(_value: any, _rules: any): void;
