export declare const checkBucketNameTest: (name: string, createBucket: boolean) => void;
