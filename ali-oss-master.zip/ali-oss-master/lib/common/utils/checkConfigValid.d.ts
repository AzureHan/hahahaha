export declare const checkConfigValid: (conf: any, key: 'endpoint' | 'region') => void;
