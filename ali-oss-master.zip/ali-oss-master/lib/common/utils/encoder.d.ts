import { THeaderEncoding } from '../../types/experimental';
export declare function encoder(str: string, encoding?: THeaderEncoding): string;
