export declare function getReqUrl(this: any, params: any): string;
