export declare function postAsyncFetch(this: any, object: any, url: any, options?: any): Promise<object>;
