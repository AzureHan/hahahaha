export declare function getAsyncFetch(this: any, taskId: any, options?: any): Promise<object>;
