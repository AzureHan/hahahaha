export declare function getBucketWorm(this: any, name: string, options: any): Promise<any>;
