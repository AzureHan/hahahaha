export declare function completeBucketWorm(this: any, name: string, wormId: string, options: any): Promise<{
    res: any;
    status: any;
}>;
