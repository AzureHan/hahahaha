/**
 * deleteBucketInventory
 * @param {String} bucketName - bucket name
 * @param {String} inventoryId
 * @param {Object} options
 */
export declare function deleteBucketInventory(this: any, bucketName: string, inventoryId: string, options?: any): Promise<{
    status: any;
    res: any;
}>;
