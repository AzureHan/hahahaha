export declare function extendBucketWorm(this: any, name: string, wormId: string, days: string | number, options: any): Promise<{
    res: any;
    status: any;
}>;
