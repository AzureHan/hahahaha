export declare function abortBucketWorm(this: any, name: string, options: any): Promise<{
    res: any;
    status: any;
}>;
