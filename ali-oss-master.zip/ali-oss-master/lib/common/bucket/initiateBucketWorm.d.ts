export declare function initiateBucketWorm(this: any, name: string, days: string, options: any): Promise<{
    res: any;
    wormId: any;
    status: any;
}>;
