
const check = require('./publish-check');

const dist = './dist/aliyun-oss-sdk.min.js';

check.checkDist(dist);
