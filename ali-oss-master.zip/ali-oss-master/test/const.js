'use strict';

const constValue = module.exports;

// oss demo callback server an ecs, used with PutObject、PostObject、CompleteMultipartUpload
constValue.callbackServer = 'http://oss-demo.aliyuncs.com:23450';
