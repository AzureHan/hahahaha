module.exports = {
  extension: ['js'],
  include: ['lib/**'],
  exclude: ['lib/common/object/getAsyncFetch.js', 'lib/common/object/postAsyncFetch.js']
};
