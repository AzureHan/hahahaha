module.exports = () => {
  return () => {}
}
